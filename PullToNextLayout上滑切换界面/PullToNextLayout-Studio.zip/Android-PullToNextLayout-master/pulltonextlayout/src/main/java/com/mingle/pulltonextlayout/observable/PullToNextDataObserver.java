package com.mingle.pulltonextlayout.observable;

import android.database.DataSetObserver;

/**
 * Created by zzz40500 on 15/5/22.
 */
public class PullToNextDataObserver extends DataSetObserver {



    public void onNewData() {
        // Do nothing
    }
}
