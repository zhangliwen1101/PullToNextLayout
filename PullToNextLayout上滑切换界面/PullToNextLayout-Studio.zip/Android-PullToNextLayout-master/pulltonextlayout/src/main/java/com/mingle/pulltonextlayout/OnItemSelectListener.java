package com.mingle.pulltonextlayout;

import android.view.View;

/**
 * Created by zzz40500 on 15/3/21.
 */
public interface OnItemSelectListener {


    public void onSelectItem(int position,View view);
}
