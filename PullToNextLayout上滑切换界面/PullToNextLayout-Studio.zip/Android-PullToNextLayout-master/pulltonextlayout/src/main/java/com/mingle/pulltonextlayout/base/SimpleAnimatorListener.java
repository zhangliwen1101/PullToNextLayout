package com.mingle.pulltonextlayout.base;


import com.nineoldandroids.animation.Animator;


/**
 * Created by zzz40500 on 15/5/30.
 */
public class SimpleAnimatorListener  implements  Animator.AnimatorListener{

    @Override
    public void onAnimationStart(Animator animation) {

    }

    @Override
    public void onAnimationEnd(Animator animation) {

    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }
}
